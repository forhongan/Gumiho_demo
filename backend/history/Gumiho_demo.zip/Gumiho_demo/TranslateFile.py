import json


class TranslateFile:
    """
    #工程文件操作类
    #translatefile_path: 工程文件路径
    #工程文件的类似格式如下:
    {  
        "title": "...", // 文集或书籍标题（可选）  
        "author": "...", // 作者（可选）
        "translator": "...", // 译者（可选）
        "description": "...", // 描述（可选）
        "chapters": [  
            {
                "id": 1, // 段落编号  
                "original-text": "第一章 启航", // 原文  
                "translation-text": "", // 译文 
                "type": "title_lv1" ,//一级标题
                "state": "f_trans_unfinished" //f_trans_unfinished, f_trans_finished,p_finished,checked,re_trans_needed
            },
            {
                "id": 2, // 段落编号  
                "original-text": "船要扬帆起航了", // 原文  
                "translation-text": "", // 译文 
                "type": "main_text" ,
                "state": "f_trans_unfinished"
            },
            {
                "id": 3, // 段落编号  
                "original-text": "王明在甲板上看着港口里的...", // 原文  
                "translation-text": "", // 译文 
                "type": "main_text" ,
                "state": "f_trans_unfinished"
            }
            ...
            {
                "id": 400, // 段落编号  
                "original-text": "第二章 沉没", // 原文  
                "translation-text": "", // 译文 
                "type": "title_lv1" ,//一级标题
                "state": "f_trans_unfinished" //f_trans_unfinished, f_trans_finished,p_finished,checked,re_trans_needed
            },
        ]
    }  
    """
    def __init__(self,translatefile_path):
        self.translatefile_path = translatefile_path
        self.data = self.read_translatefile()

    def read_translatefile(self):
        """
        读取工程文件
        """
        with open(self.translatefile_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    
    def write_translatefile(self,data):    
        """
        写入工程文件
        """
        with open(self.translatefile_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    #检查id是否为标题，标题的"type"以 "title" 开头
    def check_id_is_title(self, id):
        id = int(id)  # 转换为整数
        data = self.read_translatefile()
        for chapter in data["chapters"]:
            if chapter["id"] == id:
                return chapter.get("type", "").startswith("title")
        return False
    
    def get_chapter_end_from_id(self, id):
        """
        通过id获取章节范围，返回章节结束位置的id
        如果id不是标题则报错返回空值
        """
        id = int(id)  # 转换为整数
        if not self.check_id_is_title(id):
            print(f"Error: id {id} 对应的章节不是标题")
            return None
        chapters = self.data["chapters"]
        current_type = None
        found = False
        for i, chapter in enumerate(chapters):
            if chapter["id"] == id:
                current_type = chapter["type"]
                found = True
                continue
            if found and chapter["type"] == current_type:
                return chapter["id"] - 1
        return chapters[-1]["id"]

    def get_previous_chapter_start_from_id(self, id):
        """
        通过章节id获取上一章节的起始位置id
        如果id不是标题则报错返回空值
        """
        id = int(id)  # 转换为整数
        if not self.check_id_is_title(id):
            print(f"Error: id {id} 对应的章节不是标题")
            return None
        chapters = self.data["chapters"]
        # 首先找到当前章节在列表中的下标
        current_index = None
        for i, chapter in enumerate(chapters):
            if chapter["id"] == id:
                current_index = i
                break
        if current_index is None:
            return None
        current_type = chapters[current_index]["type"]
        # 倒序遍历当前章节之前的所有章节
        for i in range(current_index - 1, -1, -1):
            # 找到与当前章节类型相同的章节即认为是上一章节的起始
            if chapters[i]["type"] == current_type:
                return chapters[i]["id"]
        # 如果未找到，则返回第一章节的 id
        return chapters[0]["id"]
    
    def get_book_name(self):
        """
        获取书名
        """
        return self.data.get("title", "")

    #new
    def _find_start_index(self, chapters, req_state):
        # 查找首个符合条件的章节索引
        for idx, chap in enumerate(chapters):
            if chap.get("state") == req_state:
                return idx
        return None

    def _detect_paragraph_title(self, chapters, start_index,paragraphed):
        # 检测当前句前的段落标题及其索引
        paragraph_title = None
        paragraph_title_index = None
        if paragraphed:
            for idx in range(start_index, -1, -1):
                if chapters[idx].get("type") != "main_text":
                    paragraph_title = chapters[idx].get("original-text")
                    paragraph_title_index = idx
                    break
        return paragraph_title, paragraph_title_index

    def _collect_current_group(self, chapters, start_index, req_state, max_len,paragraphed):
        # 收集当前处理组中的句并返回当前组及终止ID
        current_group = []
        current_end_id = None
        for chap in chapters[start_index:]:
            if chap.get("state") != req_state:
                break
            if paragraphed and current_group and chap.get("type") != "main_text":
                break
            if len(current_group) >= max_len:
                break
            current_group.append(chap)
            current_end_id = chap["id"]
        return current_group, current_end_id

if __name__ == "__main__":
    #test
    translatefile_path = "少女所不希望的英雄史诗_project/(NEW)jp.少女所不期望的英雄史诗.json"
    efo = TranslateFile(translatefile_path)
    print(efo.get_chapter_end_from_id(1))
