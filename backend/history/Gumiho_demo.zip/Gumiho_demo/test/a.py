import os
import yaml
import json
from b import b_test

def test():
    print("a_test")
    b_test()

if __name__ == "__main__":
    test()